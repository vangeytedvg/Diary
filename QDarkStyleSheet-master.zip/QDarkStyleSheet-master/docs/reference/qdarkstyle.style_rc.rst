qdarkstyle.style\_rc module
===========================

.. automodule:: qdarkstyle.style_rc
   :members:
   :undoc-members:
   :show-inheritance:
