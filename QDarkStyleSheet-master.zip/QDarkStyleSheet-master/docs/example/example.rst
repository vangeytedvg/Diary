example module
==============

.. automodule:: example
   :members:
   :undoc-members:
   :show-inheritance:
