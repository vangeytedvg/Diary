process\_qrc module
===================

.. automodule:: process_qrc
   :members:
   :undoc-members:
   :show-inheritance:
